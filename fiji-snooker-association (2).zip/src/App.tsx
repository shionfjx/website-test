import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, 
  Calendar, 
  Image as ImageIcon, 
  Newspaper, 
  Settings, 
  Menu, 
  X, 
  ChevronRight,
  MapPin,
  Clock,
  Plus,
  Trash2,
  Lock,
  LogOut
} from 'lucide-react';
import { supabase } from './lib/supabase';
import { cn, Event, GalleryImage, NewsItem } from './types';

// --- Components ---

const Navbar = ({ hasBoardAccess }: { hasBoardAccess: boolean }) => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const links = [
    { name: 'Home', path: '/', icon: Newspaper },
    { name: 'Events', path: '/events', icon: Calendar },
    { name: 'Gallery', path: '/gallery', icon: ImageIcon },
  ];

  if (hasBoardAccess) {
    links.push({ name: 'Admin', path: '/admin', icon: Settings });
  }

  return (
    <nav className="sticky top-0 z-50 bg-white/70 backdrop-blur-xl border-b border-fiji-blue/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 bg-fiji-blue rounded-lg flex items-center justify-center text-white group-hover:rotate-12 transition-transform">
                <Trophy size={24} />
              </div>
              <span className="text-xl font-bold text-fiji-dark tracking-tight">
                Fiji <span className="text-fiji-blue">Snooker</span>
              </span>
            </Link>
          </div>

          {/* Desktop Links */}
          <div className="hidden md:flex items-center gap-8">
            {links.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={cn(
                  "nav-link flex items-center gap-2",
                  location.pathname === link.path && "active"
                )}
              >
                <link.icon size={18} />
                {link.name}
              </Link>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 text-fiji-dark hover:bg-fiji-blue/10 rounded-lg transition-colors"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-fiji-blue/10 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-2">
              {links.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-xl transition-colors",
                    location.pathname === link.path 
                      ? "bg-fiji-blue text-white" 
                      : "text-fiji-dark hover:bg-fiji-blue/10"
                  )}
                >
                  <link.icon size={20} />
                  <span className="font-medium">{link.name}</span>
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const PageWrapper = ({ children }: { children: React.ReactNode }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    transition={{ duration: 0.4 }}
    className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12"
  >
    {children}
  </motion.div>
);

// --- Pages ---

const Home = () => {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchNews = async () => {
      const { data, error } = await supabase
        .from('news')
        .select('*')
        .order('date', { ascending: false });
      
      if (!error && data) {
        setNews(data);
      }
      setLoading(false);
    };
    fetchNews();
  }, []);

  return (
    <PageWrapper>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-12">
          <header className="space-y-4">
            <h1 className="text-5xl font-extrabold text-fiji-dark leading-tight">
              Bula! Welcome to the <br />
              <span className="text-fiji-blue">Fiji Snooker Association</span>
            </h1>
            <p className="text-xl text-fiji-dark/60 max-w-2xl">
              Promoting the spirit of cue sports across the islands. Stay updated with the latest news, 
              competitions, and community events.
            </p>
          </header>

          <section className="space-y-8">
            <div className="flex items-center justify-between">
              <h2 className="text-3xl font-bold text-fiji-dark flex items-center gap-3">
                <Newspaper className="text-fiji-blue" />
                Latest Updates
              </h2>
            </div>

            {loading ? (
              <div className="space-y-4">
                {[1, 2, 3].map(i => (
                  <div key={i} className="h-32 bg-white/50 animate-pulse rounded-2xl" />
                ))}
              </div>
            ) : news.length > 0 ? (
              <div className="space-y-6">
                {news.map((item) => (
                  <motion.article
                    key={item.id}
                    whileHover={{ y: -4 }}
                    className="glass-card p-8 group cursor-default"
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                      <h3 className="text-2xl font-bold text-fiji-dark group-hover:text-fiji-blue transition-colors">
                        {item.title}
                      </h3>
                      <span className="text-sm font-medium text-fiji-blue bg-fiji-blue/10 px-4 py-1 rounded-full">
                        {new Date(item.date).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-fiji-dark/70 leading-relaxed whitespace-pre-wrap">
                      {item.content}
                    </p>
                  </motion.article>
                ))}
              </div>
            ) : (
              <div className="text-center py-20 glass-card">
                <p className="text-fiji-dark/40">No news updates at the moment.</p>
              </div>
            )}
          </section>
        </div>

        <aside className="space-y-8">
          <div className="glass-card p-8 bg-fiji-blue text-white overflow-hidden relative">
            <div className="relative z-10">
              <h3 className="text-2xl font-bold mb-4">Join the Club</h3>
              <p className="text-white/80 mb-6">
                Become a member of the FSA today and participate in national tournaments.
              </p>
              <button className="w-full py-3 bg-white text-fiji-blue rounded-xl font-bold hover:bg-fiji-sand transition-colors">
                Register Now
              </button>
            </div>
            <Trophy className="absolute -bottom-4 -right-4 w-32 h-32 text-white/10 rotate-12" />
          </div>

          <div className="glass-card p-8 space-y-6">
            <h3 className="text-xl font-bold text-fiji-dark">Quick Links</h3>
            <ul className="space-y-4">
              {['Tournament Rules', 'Membership Fees', 'Hall of Fame', 'Contact Us'].map(link => (
                <li key={link}>
                  <a href="#" className="flex items-center justify-between group text-fiji-dark/70 hover:text-fiji-blue transition-colors">
                    <span>{link}</span>
                    <ChevronRight size={16} className="group-hover:translate-x-1 transition-transform" />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </aside>
      </div>
    </PageWrapper>
  );
};

const Events = () => {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchEvents = async () => {
      const { data, error } = await supabase
        .from('events')
        .select('*')
        .order('date', { ascending: true });
      
      if (!error && data) {
        setEvents(data);
      }
      setLoading(false);
    };
    fetchEvents();
  }, []);

  return (
    <PageWrapper>
      <header className="mb-12 text-center max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold text-fiji-dark mb-4">Competitions & Events</h1>
        <p className="text-lg text-fiji-dark/60">
          Mark your calendars for upcoming snooker tournaments and association gatherings across Fiji.
        </p>
      </header>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-64 bg-white/50 animate-pulse rounded-2xl" />
          ))}
        </div>
      ) : events.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {events.map((event) => (
            <motion.div
              key={event.id}
              whileHover={{ y: -8 }}
              className="glass-card overflow-hidden flex flex-col"
            >
              <div className={cn(
                "h-2",
                event.type === 'competition' ? "bg-fiji-blue" : "bg-fiji-green"
              )} />
              <div className="p-8 flex-1 flex flex-col">
                <div className="flex items-center justify-between mb-4">
                  <span className={cn(
                    "text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full",
                    event.type === 'competition' ? "bg-fiji-blue/10 text-fiji-blue" : "bg-fiji-green/10 text-fiji-green"
                  )}>
                    {event.type}
                  </span>
                </div>
                <h3 className="text-2xl font-bold text-fiji-dark mb-4">{event.title}</h3>
                <div className="space-y-3 text-fiji-dark/60 mb-6">
                  <div className="flex items-center gap-2">
                    <Calendar size={16} />
                    <span>{new Date(event.date).toLocaleDateString('en-FJ', { dateStyle: 'long' })}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock size={16} />
                    <span>{new Date(event.date).toLocaleTimeString('en-FJ', { timeStyle: 'short' })}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin size={16} />
                    <span>{event.location}</span>
                  </div>
                </div>
                <p className="text-fiji-dark/70 line-clamp-3 mb-8">
                  {event.description}
                </p>
                <button className="mt-auto w-full py-3 border-2 border-fiji-blue/20 text-fiji-blue rounded-xl font-bold hover:bg-fiji-blue hover:text-white transition-all">
                  View Details
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="text-center py-32 glass-card">
          <Calendar size={48} className="mx-auto text-fiji-dark/20 mb-4" />
          <p className="text-fiji-dark/40">No upcoming events scheduled.</p>
        </div>
      )}
    </PageWrapper>
  );
};

const Gallery = () => {
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchGallery = async () => {
      const { data, error } = await supabase
        .from('gallery')
        .select('*');
      
      if (!error && data) {
        setImages(data);
      }
      setLoading(false);
    };
    fetchGallery();
  }, []);

  return (
    <PageWrapper>
      <header className="mb-12 text-center max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold text-fiji-dark mb-4">Image Gallery</h1>
        <p className="text-lg text-fiji-dark/60">
          Capturing the best moments from our tournaments and events across the islands.
        </p>
      </header>

      {loading ? (
        <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="h-64 bg-white/50 animate-pulse rounded-2xl" />
          ))}
        </div>
      ) : images.length > 0 ? (
        <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
          {images.map((img) => (
            <div key={img.id} className="gallery-item break-inside-avoid">
              <img 
                src={img.url} 
                alt={img.caption} 
                className="w-full h-auto object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="gallery-overlay">
                <span className="text-xs font-bold uppercase tracking-widest text-fiji-blue mb-2">
                  {img.category}
                </span>
                <p className="text-lg font-bold leading-tight">
                  {img.caption}
                </p>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-32 glass-card">
          <ImageIcon size={48} className="mx-auto text-fiji-dark/20 mb-4" />
          <p className="text-fiji-dark/40">The gallery is currently empty.</p>
        </div>
      )}
    </PageWrapper>
  );
};

const Admin = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [password, setPassword] = useState('');
  const [activeTab, setActiveTab] = useState<'news' | 'events' | 'gallery'>('news');
  
  // Form States
  const [newsForm, setNewsForm] = useState({ title: '', content: '' });
  const [eventForm, setEventForm] = useState({ title: '', date: '', location: '', description: '', type: 'competition' as const });
  const [galleryForm, setGalleryForm] = useState({ url: '', caption: '', category: 'Tournament' });

  // Data States
  const [news, setNews] = useState<NewsItem[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [gallery, setGallery] = useState<GalleryImage[]>([]);

  const fetchData = async () => {
    const { data: newsData } = await supabase.from('news').select('*').order('date', { ascending: false });
    const { data: eventsData } = await supabase.from('events').select('*').order('date', { ascending: true });
    const { data: galleryData } = await supabase.from('gallery').select('*');
    
    if (newsData) setNews(newsData);
    if (eventsData) setEvents(eventsData);
    if (galleryData) setGallery(galleryData);
  };

  useEffect(() => {
    if (isLoggedIn) fetchData();
  }, [isLoggedIn]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const { data, error } = await supabase
      .from('admins')
      .select('*')
      .eq('password', password)
      .single();

    if (data && !error) {
      setIsLoggedIn(true);
    } else {
      alert('Incorrect password');
    }
  };

  const handleAddNews = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.from('news').insert([newsForm]);
    if (error) alert(error.message);
    setNewsForm({ title: '', content: '' });
    fetchData();
  };

  const handleAddEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.from('events').insert([eventForm]);
    if (error) alert(error.message);
    setEventForm({ title: '', date: '', location: '', description: '', type: 'competition' });
    fetchData();
  };

  const handleAddGallery = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.from('gallery').insert([galleryForm]);
    if (error) alert(error.message);
    setGalleryForm({ url: '', caption: '', category: 'Tournament' });
    fetchData();
  };

  const handleDelete = async (table: string, id: number) => {
    if (!confirm('Are you sure you want to delete this item?')) return;
    const { error } = await supabase.from(table).delete().eq('id', id);
    if (error) alert(error.message);
    fetchData();
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    sessionStorage.removeItem('fsa_board_access');
    window.location.href = '/';
  };

  if (!isLoggedIn) {
    return (
      <PageWrapper>
        <div className="max-w-md mx-auto mt-20">
          <div className="glass-card p-10 text-center">
            <div className="w-16 h-16 bg-fiji-blue/10 rounded-full flex items-center justify-center mx-auto mb-6 text-fiji-blue">
              <Lock size={32} />
            </div>
            <h1 className="text-2xl font-bold text-fiji-dark mb-2">Admin Access</h1>
            <p className="text-fiji-dark/60 mb-8">Please enter the association password to manage content.</p>
            <form onSubmit={handleLogin} className="space-y-4">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                className="w-full px-6 py-3 bg-fiji-sand/30 border border-fiji-blue/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-fiji-blue/50 transition-all"
              />
              <button type="submit" className="btn-fiji w-full py-4">
                Login to Dashboard
              </button>
            </form>
          </div>
        </div>
      </PageWrapper>
    );
  }

  return (
    <PageWrapper>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h1 className="text-4xl font-bold text-fiji-dark">Admin Dashboard</h1>
          <p className="text-fiji-dark/60">Manage your association's content and updates.</p>
        </div>
        <button 
          onClick={handleLogout}
          className="flex items-center gap-2 px-6 py-2 text-red-500 hover:bg-red-50 rounded-full transition-colors font-medium"
        >
          <LogOut size={18} />
          Logout
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
        <aside className="lg:col-span-1 space-y-2">
          {[
            { id: 'news', name: 'Daily News', icon: Newspaper },
            { id: 'events', name: 'Events & Dates', icon: Calendar },
            { id: 'gallery', name: 'Image Gallery', icon: ImageIcon },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "w-full flex items-center gap-3 px-6 py-4 rounded-2xl font-bold transition-all",
                activeTab === tab.id 
                  ? "bg-fiji-blue text-white shadow-lg shadow-fiji-blue/20 scale-105" 
                  : "text-fiji-dark/60 hover:bg-fiji-blue/5"
              )}
            >
              <tab.icon size={20} />
              {tab.name}
            </button>
          ))}
        </aside>

        <main className="lg:col-span-3 space-y-12">
          {activeTab === 'news' && (
            <div className="space-y-12">
              <section className="glass-card p-8">
                <h2 className="text-2xl font-bold text-fiji-dark mb-6 flex items-center gap-2">
                  <Plus className="text-fiji-blue" /> Add News Update
                </h2>
                <form onSubmit={handleAddNews} className="space-y-4">
                  <input
                    type="text"
                    placeholder="News Title"
                    required
                    value={newsForm.title}
                    onChange={e => setNewsForm({ ...newsForm, title: e.target.value })}
                    className="w-full px-6 py-3 bg-fiji-sand/30 border border-fiji-blue/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-fiji-blue/50"
                  />
                  <textarea
                    placeholder="Content details..."
                    required
                    rows={5}
                    value={newsForm.content}
                    onChange={e => setNewsForm({ ...newsForm, content: e.target.value })}
                    className="w-full px-6 py-3 bg-fiji-sand/30 border border-fiji-blue/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-fiji-blue/50"
                  />
                  <button type="submit" className="btn-fiji">Publish News</button>
                </form>
              </section>

              <section className="space-y-4">
                <h3 className="text-xl font-bold text-fiji-dark">Existing News</h3>
                <div className="space-y-4">
                  {news.map(item => (
                    <div key={item.id} className="glass-card p-6 flex items-start justify-between gap-4">
                      <div>
                        <h4 className="font-bold text-fiji-dark">{item.title}</h4>
                        <p className="text-sm text-fiji-dark/60 mb-2">{new Date(item.date).toLocaleDateString()}</p>
                        <p className="text-fiji-dark/70 line-clamp-2">{item.content}</p>
                      </div>
                      <button 
                        onClick={() => handleDelete('news', item.id)}
                        className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  ))}
                </div>
              </section>
            </div>
          )}

          {activeTab === 'events' && (
            <div className="space-y-12">
              <section className="glass-card p-8">
                <h2 className="text-2xl font-bold text-fiji-dark mb-6 flex items-center gap-2">
                  <Plus className="text-fiji-blue" /> Add Competition/Event
                </h2>
                <form onSubmit={handleAddEvent} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="Event Title"
                    required
                    value={eventForm.title}
                    onChange={e => setEventForm({ ...eventForm, title: e.target.value })}
                    className="col-span-full px-6 py-3 bg-fiji-sand/30 border border-fiji-blue/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-fiji-blue/50"
                  />
                  <input
                    type="datetime-local"
                    required
                    value={eventForm.date}
                    onChange={e => setEventForm({ ...eventForm, date: e.target.value })}
                    className="px-6 py-3 bg-fiji-sand/30 border border-fiji-blue/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-fiji-blue/50"
                  />
                  <input
                    type="text"
                    placeholder="Location"
                    required
                    value={eventForm.location}
                    onChange={e => setEventForm({ ...eventForm, location: e.target.value })}
                    className="px-6 py-3 bg-fiji-sand/30 border border-fiji-blue/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-fiji-blue/50"
                  />
                  <select
                    value={eventForm.type}
                    onChange={e => setEventForm({ ...eventForm, type: e.target.value as any })}
                    className="px-6 py-3 bg-fiji-sand/30 border border-fiji-blue/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-fiji-blue/50"
                  >
                    <option value="competition">Competition</option>
                    <option value="event">General Event</option>
                  </select>
                  <textarea
                    placeholder="Event description..."
                    required
                    rows={3}
                    value={eventForm.description}
                    onChange={e => setEventForm({ ...eventForm, description: e.target.value })}
                    className="col-span-full px-6 py-3 bg-fiji-sand/30 border border-fiji-blue/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-fiji-blue/50"
                  />
                  <button type="submit" className="btn-fiji col-span-full">Create Event</button>
                </form>
              </section>

              <section className="space-y-4">
                <h3 className="text-xl font-bold text-fiji-dark">Upcoming Events</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {events.map(item => (
                    <div key={item.id} className="glass-card p-6 flex items-start justify-between gap-4">
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-widest text-fiji-blue mb-1 block">
                          {item.type}
                        </span>
                        <h4 className="font-bold text-fiji-dark">{item.title}</h4>
                        <p className="text-xs text-fiji-dark/60">{new Date(item.date).toLocaleString()}</p>
                        <p className="text-xs text-fiji-dark/60">{item.location}</p>
                      </div>
                      <button 
                        onClick={() => handleDelete('events', item.id)}
                        className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  ))}
                </div>
              </section>
            </div>
          )}

          {activeTab === 'gallery' && (
            <div className="space-y-12">
              <section className="glass-card p-8">
                <h2 className="text-2xl font-bold text-fiji-dark mb-6 flex items-center gap-2">
                  <Plus className="text-fiji-blue" /> Add Image to Gallery
                </h2>
                <form onSubmit={handleAddGallery} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input
                    type="url"
                    placeholder="Image URL (e.g. https://...)"
                    required
                    value={galleryForm.url}
                    onChange={e => setGalleryForm({ ...galleryForm, url: e.target.value })}
                    className="col-span-full px-6 py-3 bg-fiji-sand/30 border border-fiji-blue/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-fiji-blue/50"
                  />
                  <input
                    type="text"
                    placeholder="Caption"
                    required
                    value={galleryForm.caption}
                    onChange={e => setGalleryForm({ ...galleryForm, caption: e.target.value })}
                    className="px-6 py-3 bg-fiji-sand/30 border border-fiji-blue/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-fiji-blue/50"
                  />
                  <input
                    type="text"
                    placeholder="Category (e.g. Tournament)"
                    required
                    value={galleryForm.category}
                    onChange={e => setGalleryForm({ ...galleryForm, category: e.target.value })}
                    className="px-6 py-3 bg-fiji-sand/30 border border-fiji-blue/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-fiji-blue/50"
                  />
                  <button type="submit" className="btn-fiji col-span-full">Add to Gallery</button>
                </form>
              </section>

              <section className="space-y-4">
                <h3 className="text-xl font-bold text-fiji-dark">Gallery Items</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {gallery.map(item => (
                    <div key={item.id} className="glass-card overflow-hidden group relative aspect-square">
                      <img src={item.url} alt={item.caption} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <button 
                          onClick={() => handleDelete('gallery', item.id)}
                          className="p-3 bg-white text-red-500 rounded-full shadow-xl hover:scale-110 transition-transform"
                        >
                          <Trash2 size={20} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            </div>
          )}
        </main>
      </div>
    </PageWrapper>
  );
};

const NotFound = () => (
  <PageWrapper>
    <div className="text-center py-32">
      <h1 className="text-9xl font-black text-fiji-blue/20 mb-4">404</h1>
      <h2 className="text-3xl font-bold text-fiji-dark mb-4">Page Not Found</h2>
      <p className="text-fiji-dark/60 mb-8">The page you are looking for doesn't exist or has been moved.</p>
      <Link to="/" className="btn-fiji">
        Return Home
      </Link>
    </div>
  </PageWrapper>
);

// --- Main App ---

export default function App() {
  const [hasBoardAccess, setHasBoardAccess] = useState(false);

  useEffect(() => {
    const checkAccess = () => {
      const hasAccess = sessionStorage.getItem('fsa_board_access') === 'true';
      const params = new URLSearchParams(window.location.search);
      const secretParam = params.get('portal') === 'board';

      if (hasAccess || secretParam) {
        setHasBoardAccess(true);
        if (secretParam) {
          sessionStorage.setItem('fsa_board_access', 'true');
        }
      }
    };
    
    checkAccess();
    window.addEventListener('storage', checkAccess);
    return () => window.removeEventListener('storage', checkAccess);
  }, []);

  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Navbar hasBoardAccess={hasBoardAccess} />
        <main className="flex-1">
          <AnimatePresence mode="wait">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/events" element={<Events />} />
              <Route path="/gallery" element={<Gallery />} />
              <Route 
                path="/admin" 
                element={hasBoardAccess ? <Admin /> : <NotFound />} 
              />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </AnimatePresence>
        </main>
        
        <footer className="bg-fiji-dark text-white py-12 mt-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-fiji-blue rounded flex items-center justify-center text-white">
                    <Trophy size={18} />
                  </div>
                  <span className="text-lg font-bold">Fiji Snooker Association</span>
                </div>
                <p className="text-white/60 text-sm leading-relaxed">
                  The official governing body for snooker and billiards in Fiji. 
                  Committed to excellence and sportsmanship.
                </p>
              </div>
              
              <div className="space-y-4">
                <h4 className="font-bold">Contact Info</h4>
                <ul className="space-y-2 text-white/60 text-sm">
                  <li>Suva, Fiji Islands</li>
                  <li>Email: info@fijisnooker.org.fj</li>
                  <li>Phone: +679 123 4567</li>
                </ul>
              </div>
              
              <div className="space-y-4">
                <h4 className="font-bold">Follow Us</h4>
                <div className="flex gap-4">
                  {['FB', 'IG', 'TW'].map(social => (
                    <a key={social} href="#" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-fiji-blue hover:border-fiji-blue transition-all">
                      {social}
                    </a>
                  ))}
                </div>
              </div>
            </div>
            <div className="border-t border-white/10 mt-12 pt-8 text-center text-white/40 text-xs">
              &copy; {new Date().getFullYear()} Fiji Snooker Association. All rights reserved.
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
}
