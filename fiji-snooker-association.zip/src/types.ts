import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export interface Event {
  id: number;
  title: string;
  date: string;
  location: string;
  description: string;
  type: 'competition' | 'event';
}

export interface GalleryImage {
  id: number;
  url: string;
  caption: string;
  category: string;
}

export interface NewsItem {
  id: number;
  title: string;
  content: string;
  date: string;
}

export interface SiteSettings {
  site_name: string;
  admin_password?: string;
}
